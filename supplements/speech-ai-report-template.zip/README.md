# Speech Processing and Human-Machine Interaction: Report Template

This is the Prism project template for the midterm report and the final paper.
Both use the format of an **Interspeech long paper**, built on the official Interspeech 2026
paper kit. The blue boxes in the `.tex` files contain guidance on writing and research;
red brackets mark the places you still have to write.

## Layout

```
(project root)
├── README.md               this file
├── Interspeech.cls         official Interspeech class (do not edit)
├── IEEEtran.bst            official bibliography style (do not edit)
├── report-guide.sty        macros for the guidance boxes, markers and fonts (do not edit)
├── midterm/                midterm report: research proposal + proof of concept
│   ├── main.tex            <- compile this file: the report
│   ├── supplementary.tex   <- and this one, if you use it: the supplementary material
│   ├── metadata.tex        title, authors, student IDs, emails, keywords
│   ├── references.bib      bibliography of the midterm report
│   ├── Interspeech.cls     identical to the copy in the root (see FAQ)
│   ├── IEEEtran.bst        identical to the copy in the root (see FAQ)
│   ├── figures/
│   └── sections/           one .tex file per section
└── final/                  final paper: a complete Interspeech long paper
    ├── main.tex
    ├── supplementary.tex
    ├── metadata.tex
    ├── references.bib
    ├── Interspeech.cls
    ├── IEEEtran.bst
    ├── figures/
    └── sections/
```

## Getting started

The topic is yours to choose, as long as it is a problem about speech: recognizing,
understanding, generating or evaluating it, or interacting with machines through it.

1. Import the template (the zip file) into Prism as a new project.
2. Rename the project to `[Speech-AI] <title>`, where `<title>` is the English title of your
   report (for example, `[Speech-AI] Tone Sandhi Errors in Taiwanese ASR`). Then share it with
   the instructor (hungshinlee@gmail.com) with edit access. One group member imports the
   template and shares the project with the other members too; a working title is fine until
   the topic is settled. Sharing the project is how you hand in: there is no separate PDF to
   submit. The instructor announces each deadline; at the midterm deadline, the instructor
   compiles `midterm/main.tex` as it stands and grades that PDF, so make sure it compiles.
3. Compile `midterm/main.tex` for the midterm report and `final/main.tex` for the final paper,
   with pdfLaTeX (the default) and BibTeX. `supplementary.tex` in the same folder is a separate
   document; compile it on its own if you use it. If your paper must show Chinese, Taiwanese
   Hokkien or Hakka text, read "Chinese or Taiwanese text in the PDF" below first.
4. Compile once and read every blue box in the PDF before you start writing.
   For the midterm, start with the six "Before you write" boxes after the abstract: they cover
   how to find, investigate and choose a problem. Keep a record of your candidates, searches
   and AI-assisted steps from the first day; the supplementary material has an optional section
   (Problem Discovery Log) where you can include it.
5. Fill in `metadata.tex`. For each group member: the English name exactly as it appears on
   the passport, given name first (e.g. `\author[affiliation={1}]{Hung-Shin}{Lee}`), the
   student ID, and an email address.

## Four markers

| Marker | Looks like | Meaning |
|---|---|---|
| `\begin{guide}...\end{guide}` | blue box | Guidance on writing and research. Delete it when you are done, or keep it in the source and hide it with `\showguidesfalse`. |
| `\fillin{...}` | red brackets | Text you still have to write. |
| `\pending` | red *pending* | A number you have not measured yet. |
| `\src{Sec.~4.2}` | small grey *[Sec. 4.2]* | Where, in the paper you just cited, the claim you attribute to it appears. |

- Change `\showguidestrue` to `\showguidesfalse` in `main.tex` and all blue boxes disappear,
  so you can see the real length of your report.
- The red markers do **not** disappear. **Before the deadline, set `\showguidesfalse` in `main.tex`,
  compile, and look through the PDF: no red marker may remain.** One exception: in the midterm report,
  the cells of the planned-results table (Evaluation Plan) stay `\pending` until the final
  paper. In the proof-of-concept table, delete a row you did not run, and write `--` where
  there is no published or predicted value to expect. (Searching the source also finds the
  markers that the guidance boxes mention; the PDF is what counts.)
- **Every measured number in every table must come from your own code.** If you have not run
  it yet, write `\pending`; never fill a cell with the value you hope to get. The only other
  numbers allowed are ones labeled as such: rows marked as reported by other papers; the
  "Expected" column of the midterm's proof-of-concept table (the published or predicted value
  you compare against); and planned quantities labeled as plans, such as the target size of a
  corpus you will record or an estimate of GPU hours (`50 (target)`, `about 20 GPU-hours
  (estimate)`).
- **Every claim you attribute to a paper carries `\src{...}`**, placed right after the citation:
  `Smith et al.~\cite{smith2024}\src{Sec.~4.2, Tab.~3} show that ...`. When one sentence
  attributes two claims to the same paper, give each claim its own note. Open the PDF, find the
  passage, write where it is. Citations that only point to a work ("we use the toolkit
  of [X]") do not need one. The grey notes stay in the PDF for this course
  (`\showsourcestrue` in `main.tex`).

## Length (Interspeech long paper)

- At most **10 pages**. Pages 9 and 10 are reserved for three sections only: Acknowledgments,
  Generative AI Use Disclosure, and References (they may start earlier if there is space).
- Everything else must fit in the **first 8 pages**: text, figures, tables, the Limitations
  and Ethical considerations sections, and any appendix.
- What does not fit goes into the supplementary material (`supplementary.tex`), which
  reviewers may read but are not required to. The paper must be understandable without it.
- These limits apply to the final paper. The midterm report has no length limit, in either
  direction; it keeps the same layout.
- For comparison, an Interspeech regular paper has at most 6 pages: 4 of content and 2 reserved.
  The final paper of this course is a long paper.

## References

- Interspeech uses numbered references in the IEEEtran style. Write `\cite{key}`, and name the
  authors in the sentence when they are its subject: `Kirkland et al.~\cite{kirkland2023mos}`.
- Each report has its own `references.bib` in its folder. When you start the final paper,
  copy the entries you still cite from `midterm/references.bib`.
- **Export every entry from an official source**: ISCA Archive, IEEE Xplore, ACL Anthology,
  PMLR, OpenReview, DBLP, or the paper's DOI page; for a paper that exists only on arXiv,
  `arxiv.org/abs/<id>`. Do not type entries from memory, and do not let an AI assistant
  produce them: AI assistants invent plausible-looking papers that do not exist.
- **Every entry has a `doi` or a `url` field** that points to its official record, so that
  anyone can check it with one click (a course rule; the official exports include one).
- ISCA's policy: cite peer-reviewed publications. Cite non-peer-reviewed sources (arXiv,
  software, personal communications) only when no peer-reviewed version exists, and keep them
  to a minimum. arXiv's "Comments" line is often not updated after acceptance, so search the
  ISCA Archive and IEEE Xplore by title too.
- Technical reports, model cards, blog posts and leaderboards are cited under the same policy,
  but say what they are in the sentence itself ("the X technical report, which is not
  peer-reviewed, states ..."), and give the date you read a number from a model card or a
  leaderboard.
- **Verify every citation** at three levels: it exists in an official record; the title,
  authors, venue and year match that record; and the claim you attribute is in the paper
  (that is what `\src` records). Cross-checking levels 2 and 3 with a second AI assistant is
  allowed, if it is a different assistant from the one that found the paper and it works
  from the PDF and the official record. Wherever it disagrees with you, read the paper yourself.
- The entries already in `references.bib` are examples used by the guidance boxes; they were
  checked against their official pages on 2026-10-16. Delete them once your paper no longer
  cites them.

## Page layout

The template uses the Interspeech **camera-ready** layout, which shows the author names, and
adds **line numbers**, so that feedback can refer to lines.
For a real Interspeech submission, change `\documentclass[cameraready]{Interspeech}` to
`\documentclass{Interspeech}` (the anonymous review layout, which has line numbers of its own),
delete the `\AtBeginDocument{\linenumbers}` line, change `\showsourcestrue` to
`\showsourcesfalse` so that the grey `\src` notes disappear, and remove the Acknowledgments:
Interspeech allows them only in the camera-ready version.

## Chinese or Taiwanese text in the PDF

Interspeech papers are written in English, but examples often need Han characters (error
cases, transcripts, a table of outputs). pdfLaTeX cannot typeset Chinese characters. If your
paper must show Chinese, Taiwanese Hokkien or Hakka text in Han characters:

1. Switch the compiler of the project to **XeLaTeX**. Nothing else in `main.tex` has to change:
   under XeLaTeX the template uses TeX Gyre Termes, Heros and Cursor (similar to the Times,
   Helvetica and Courier of `Interspeech.cls`) for Latin text, and looks for an installed
   Traditional Chinese font. Compile `supplementary.tex` the same way if it shows Chinese too.
2. Wrap every piece of Chinese in `\zh{...}`, e.g. `\zh{台語}`, also inside tables and
   captions. Lines break between Chinese characters inside `\zh`. Never in the abstract:
   Interspeech requires it to be ASCII only.
3. Compile and **search the log for `Missing character`**. A character the font does not have
   is left out of the PDF without an error. Two cases are common:
   - Tâi-lô and POJ tone marks such as the vertical line in *a̍* (U+030D) or the dot in *o͘*
     (U+0358) are missing from TeX Gyre Termes. Name a Latin font that has them in `main.tex`,
     e.g. `\def\reportmainfont{Liberation Serif}` or `\def\reportmainfont{FreeSerif}` if your
     installation has them, and look at the result.
   - Some Han characters used to write Taiwanese Hokkien lie outside the common Chinese fonts
     (*𪜶*, U+2A736, is missing from the version of Noto Serif CJK TC we tested, for instance). Name a font that has
     them with `\def\reportzhfont{...}`, or give the word in romanization.
4. If you use `\zh` and compile with pdfLaTeX, the compilation stops with a message telling
   you to switch to XeLaTeX.

The XeLaTeX setup was tested with TeX Live 2023; it has **not** yet been tested in Prism,
whose installed fonts may differ. If the log says that no Traditional Chinese font was found,
ask the instructor.

## FAQ

**Why are there three copies of `Interspeech.cls` and `IEEEtran.bst`?**
LaTeX and BibTeX look for these files only in a few fixed places. Prism may run them in the
project root or inside `midterm/` or `final/`; with a copy in each place, they are found
either way. The copies are identical to the official kit. Do not edit or delete any of them.

**What is the `Path setup` block at the top of `main.tex`?**
It lets LaTeX find `report-guide.sty`, `metadata.tex` and the sections whether it runs in the
project root or inside the folder. Do not edit it.

**BibTeX says `I found no \citation commands`.**
The document cites nothing yet: in the untouched template, all citations are inside the blue
boxes, so hiding the boxes leaves no `\cite` at all. The message goes away once you cite
something. If your `supplementary.tex` cites nothing, delete its two bibliography lines.

**Can I write Chinese in comments?**
Yes. Comments starting with `%` never reach the PDF, so Chinese is fine there under any
compiler.

**Can I use Prism's built-in AI?**
Yes, under the same rules as any other AI assistant (see the Generative AI Use Disclosure
section): use it for editing and for checking, never to produce references, BibTeX entries or
numbers, and say in the disclosure what you used it for.

**Can I use `\paragraph`?**
No: the Interspeech class does not support it, and allows at most three levels of headings
(`\section`, `\subsection`, `\subsubsection`). Start the paragraph with bold text instead:
`\noindent\textbf{Closest work.}`.

---

`Interspeech.cls`, `IEEEtran.bst` and the page and formatting rules quoted in the guidance come
from the official Interspeech 2026 paper kit (`Interspeech.cls` version 2025-09-02).
The Interspeech 2027 rules may differ; check its call for papers when it is published.
