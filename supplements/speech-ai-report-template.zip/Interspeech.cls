%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% File:     Interspeech.cls % class file for Interspeech
%
% Version: 2025-09-02 Version for Interspeech 2026
%
% Usage:    \documentclass{Interspeech}
%
% Purpose:
%
% Style file for Interspeech Conference.
% Modified from previous Interspeech conferences
% Features:
%    - correct page size (175mm x 226mm)
%    - use Times-Roman font as default font (roman font) in order to achieve
%      best quality on paper and screen
%    - two-column format
%    - boldfaced, numbered, and centered section headings
%    - correct subsection and subsubsection headings
%    - \sloppy is now the default but can be changed to \fussy by
%      specifying it as a package option (i.e. \usepackage[fussy]{Interspeech})
%    - use \title{xx} for title, will be typeset all uppercase
%    - use \name{xx} for author name(s) only, will be typeset in italics
%    - use \address{xx} for authors' address, one per line
%    - use \email{xx} for authors' email addresses, will be typeset
%      in proportional typeface
%    - note: no need for \author nor \date
%    - optional: can use \thanks{xx} within \name, asterisk is
%      not printed after name nor in footnote
%    - optional: can use \sthanks{xx} after each name within \name,
%      footnote symbol will appear for each name and footnote
%
%
% PLEASE REPORT ANY BUGS to the Technical Chairs of the current Interspeech
%
% Author:  Stephen Martucci  -- martucci@cdg.nj.nec.com
% Modifications: Jyri Huopaniemi -- jyri.huopaniemi@nokia.com
%                Matti Karjalainen -- matti.karjalainen@hut.fi
%                Panayiotis Georgiou -- panayiotis.georgiou@gmail.com
%                Mattias Heldner -- heldner@ling.su.se
%                Marcin W??odarczak -- wlodarczak@ling.su.se
%                Prasanta Ghosh -- prasantag@gmail.com
%                Simon King -- Simon.King@ed.ac.uk
%                Sébastien Le Maguer -- sebastien.lemaguer@helsinki.fi
%                Luciana Ferrer -- lferrer@dc.uba.ar
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{Interspeech}[2025/09/02 Official Interspeech 2026 package]

\newif\ifcameraready
\camerareadyfalse
\DeclareOption{cameraready}{\camerareadytrue}

\newif\if@fussy
\DeclareOption{fussy}{%
  \@fussytrue
}

% Process all options
\ProcessOptions\relax

\LoadClass[a4paper]{article}

\RequirePackage{graphicx}
\RequirePackage{amssymb,amsmath,bm}
\RequirePackage{textcomp}
\RequirePackage{booktabs}
\RequirePackage[textfont=it,tableposition=top]{caption}
\RequirePackage{siunitx}
\RequirePackage{xspace}
\RequirePackage{url}
\RequirePackage{lipsum}
\RequirePackage{tipa}
\RequirePackage{enumitem}
\RequirePackage{xkeyval}
\RequirePackage{calc}
\RequirePackage{xcolor}
\RequirePackage{tikz}
\RequirePackage[switch]{lineno}

% hyperref is used to ensure author names
% do not appear in PDF metadata
% also make sure not to mention Interspeech in the metadata in case authors place their review version of the PDF online
\RequirePackage[
        pdfauthor={Author name(s) withheld},
        pdftitle={Under review},
        colorlinks=false,
        pdfborder={0 0 0}  % This removes the border entirely
]{hyperref}


%change default font to Times-Roman
\renewcommand{\sfdefault}{phv}
\renewcommand{\rmdefault}{ptm}
\renewcommand{\ttdefault}{pcr}


% but we also tell hyperref to disable hyperlinks
\AtBeginDocument{} % \NoHyper}
% reasonably compact lists
\AtBeginDocument{\setlist{noitemsep,topsep=2pt,parsep=2pt,partopsep=0pt,leftmargin=1em}}

% Define abstract environment and keywords command (to be stored in metadata)
\def\keywords#1{\gdef\@keywords{#1}}
\gdef\@keywords{{Some keywords}}

% Redefine authors to save in metadata

% Define ORCID logo using TikZ
\definecolor{lime}{HTML}{A6CE39}
\DeclareRobustCommand{\orcidlogo}{%
	\begin{tikzpicture}
	\draw[lime, fill=lime] (0,0) 
	circle [radius=0.16] 
	node[white] {{\fontfamily{qag}\selectfont \tiny ID}};
	\draw[white, fill=white] (-0.0625,0.095) 
	circle [radius=0.007];
	\end{tikzpicture}
	\hspace{-2mm}
}

\newcommand{\authorsep}{}
\newcommand{\authorlist}{}
\newcommand{\metadataOrcid}{}
\newcommand{\orcid}{}
\newcommand{\metadataauthors}{}
\newif\ifequalcontribution
\equalcontributionfalse\define@key{authorkeys}{equalcontribution}[true]{%
  \def\author@equalcontribution{#1}%
}

\newif\ifcorrespondingauthor
\correspondingauthorfalse
\define@key{authorkeys}{correspondingauthor}[true]{%
  \def\author@correspondingauthor{#1}%
}

\define@key{authorkeys}{orcid}{%
  \def\author@orcid{#1}%
}

\define@key{authorkeys}{affiliation}{\def\author@affiliation{#1}}
\newcommand{\orcidURL}[1]{\href{https://orcid.org/#1}{\orcidlogo}}
\renewcommand{\author}[3][]{%
    \def\author@affiliation{}
    \def\author@equalcontribution{}
    \def\author@correspondingauthor{}
    \def\author@orcid{}%
    \setkeys{authorkeys}{#1} % Process the optional affiliation key

    \ifx\author@orcid\@empty
        \edef\metadataOrcid{\metadataOrcid ; }
        \def\orcid{}
        % \PackageError{Interspeech}{Missing required option `orcid' You must specify orcid={....} in the optional argument.}%
    \else
        \edef\metadataOrcid{\metadataOrcid \author@orcid; }
        \def\orcid{\orcidURL{\author@orcid}}
    \fi

    % Add author information to the list
    \ifx\author@affiliation\@empty
        \ifx\author@equalcontribution\@empty
            \ifx\author@correspondingauthor\@empty
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid}
                \edef\metadataauthors{\metadataauthors #2 \{#3\}; }
            \else
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{**}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\}; }
                \global\correspondingauthortrue
            \fi
        \else
            \ifx\author@correspondingauthor\@empty
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{*}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\}; }
                \global\equalcontributiontrue
            \else
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{*,**}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\}; }
                \global\equalcontributiontrue
                \global\correspondingauthortrue
            \fi
        \fi
    \else
        \ifx\author@equalcontribution\@empty
            \ifx\author@correspondingauthor\@empty
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{\author@affiliation}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\} \{\author@affiliation\}; }
            \else
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{\author@affiliation,**}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\} \{\author@affiliation\}; }
                \global\correspondingauthortrue
            \fi
        \else
            \ifx\author@correspondingauthor\@empty
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{\author@affiliation,*}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\} \{\author@affiliation\}; }
                \global\equalcontributiontrue
            \else
                \protected@edef\authorlist{\authorlist\authorsep{}#2 #3\orcid$^{\author@affiliation,*,**}$}
                \edef\metadataauthors{\metadataauthors #2 \{#3\} \{\author@affiliation\}; }
                \global\equalcontributiontrue
                \global\correspondingauthortrue
            \fi
        \fi
    \fi
    \renewcommand{\authorsep}{, } % Set the comma for the next author
}

% Remove the last comma and space
\preto\authorlist{\unskip} % Remove last space
\preto\authorlist{\unskip} % Remove last comma

% Refine Affiliation Management
\def\address#1{\gdef\@address{#1\\}}
\gdef\@address{Address - Line 1 \\
               Address - Line 2 \\
               Address - Line 3}

\if@fussy
  \fussy
\else
  \sloppy
\fi

\def\vec#1{\ensuremath{\bm{{#1}}}}
\def\mat#1{\vec{#1}}

\renewcommand{\section}{\@startsection
  {section}%
  {1}%
  {}%
  {-\baselineskip}%
  {0.5\baselineskip}%
  {}}%

\renewcommand{\subsection}{\@startsection
  {subsection}%
  {2}%
  {}%
  {-\baselineskip}%
  {0.5\baselineskip}%
  {}}%

\renewcommand{\subsubsection}{\@startsection
  {subsubsection}%
  {3}%
  {}%
  {-\baselineskip}%
  {0.5\baselineskip}%
  {}}%

%% these are the A4 settings
\oddsidemargin -0.20in % -0.31in
\evensidemargin -0.20in % -0.31in
\topmargin 0truept
\headheight 0truept
\footskip 0truept % 0truept
\textheight 235truemm % 226truemm
\textwidth 170truemm % 175truemm
\voffset -41truept % -14truept
\headsep 43truept % 18truept

\twocolumn
\columnsep 10truemm % 8truemm
%% end of A4 settings

%% This is for the US 8.5 x 11 paper size
%%\oddsidemargin  -0.31in
%%\evensidemargin -0.31in
%%
%%\topmargin 0truept
%%\headheight 0truept
%%\headsep 0truept
%%\footheight 0truept % for some reason this was left commented out for is2006
%%\footskip 0truept   % for some reason this was left commented out for is2006
%%\textheight 226truemm
%%\textwidth 175truemm
%%
%%\twocolumn
%%\columnsep 8truemm
%% end of 8.5x11 bit

\pagestyle{empty}
\def\ninept{\def\baselinestretch{0.95}\let\normalsize\small\normalsize}
\def\eightpt{\def\baselinestretch{0.95}\let\normalsize\footnotesize\normalsize}
% Make 9pt the default
\ninept

% SLM: I added this as it may be helpful for the reviewers to point to a given line
%\renewcommand{\makeLineNumber}{\llap{\linenumberfont\rlap{\LineNumber}\hspace{1cm}}}
\AtBeginDocument{
    \ifcameraready\else
        \linenumbers
    \fi
}

\newcommand\anonname{
    \ifcameraready
        \authorlist
        \hypersetup{
            pdftitle={\@title},
            pdfauthor={\metadataauthors},
            pdfkeywords={\@keywords},
            pdfinfo={Orcid=\metadataOrcid},
        }
    \else
         Anonymous submission to Interspeech 2026
    \fi
}

\newcommand\anonaddress{
    \ifcameraready
        \@address
    \fi
}

\newcommand\anonemail{
    \ifcameraready
	\@email
    \fi
}

% Helper to prevent latex to create an anchor
\newcommand*{\nolink}[1]{%
  {\protect\NoHyper#1\protect\endNoHyper}%
}


\def\maketitle{\par
    \begingroup
    \if@twocolumn
        \twocolumn[\@maketitle]
    \else \newpage
        \global\@topnum\z@ \@maketitle \fi\@thanks
    \endgroup
    \ifcameraready
        \ifequalcontribution
            \nolink{
                \def\thefootnote{*}
                \footnotetext{These authors contributed equally.}
                \def\thefootenote{\arabic{footnote}}
            }
        \fi

        \ifcorrespondingauthor
            \nolink{
                \def\thefootnote{**}
                \footnotetext{indicates the corresponding author.}
                \def\thefootenote{\arabic{footnote}}
            }
        \fi
    \fi
}


\newdimen\defaulttitleboxheight
\defaulttitleboxheight=5cm

\def\@maketitle{
    \newpage
    \newbox\titlebox
    \setbox\titlebox=\vbox{%
    \hsize=\textwidth
    \begin{center}
        {\large \bf \@title \par}
        \vskip 14pt
        {
            \large
            \textit{\anonname}
            \vskip 11pt
            \anonaddress
        }
        \vskip 3pt
        {\small\texttt{\anonemail}}
        \par
    \end{center}
    \par
    \thispagestyle{empty}
    \vskip 9pt
    }

    \newdimen\titleboxheight
    \titleboxheight=\ht\titlebox
    \ifdim\titleboxheight<\defaulttitleboxheight
      \titleboxheight=\defaulttitleboxheight
    \fi

    \vbox to \titleboxheight{%
        \unvbox\titlebox
        \vfill
    }
}

\def\title#1{\gdef\@title{\Large{#1}}}
% \def\name#1{\gdef\@name{#1\\}}
\def\address#1{\gdef\@address{#1\\}}
\def\email#1{\gdef\@email{#1}}
\gdef\@title{{Title of paper}}
% \gdef\@name{{\em Name of author}\\}
\gdef\@email{email@address}



\let\@@savethanks\thanks
\def\thanks#1{\gdef\thefootnote{}\@@savethanks{#1}}
\def\sthanks#1{\gdef\thefootnote{\fnsymbol{footnote}}\@@savethanks{#1}}

\def\@sect#1#2#3#4#5#6[#7]#8{
   \refstepcounter{#1}\edef\@svsec{\csname the#1\endcsname.\hskip 0.6em}
       \begingroup \ifnum #2=1\bf\centering
          {\interlinepenalty \@M
          \large{\@svsec #8}\par}\else\ifnum #2=2\bf
          \noindent{\interlinepenalty \@M \@svsec #8\par}\else
            \it
            \ifnum #2=3
            \noindent{\interlinepenalty \@M \@svsec #8\par}
            \else\@hangfrom{\hskip\parindent}{\interlinepenalty \@M
             \@svsec #8\par}\fi\fi\fi\endgroup
       \csname #1mark\endcsname{#7}\addcontentsline
         {toc}{#1}{\protect\numberline{\csname the#1\endcsname} #7}
     \@tempskipa #5\relax
     \@xsect{\@tempskipa}}

\def\abstract{\begin{center}
{\bf \large Abstract\vspace{-.5em}\vspace{2pt}}
\end{center}}
\def\endabstract{\par
\noindent{\bf Index Terms}: \@keywords}

\def\copyrightnotice#1{\gdef\@copyrightnotice{#1}}\let\@copyrightnotice\relax
\def\toappear#1{\gdef\@toappear{#1}}\let\@toappear\relax

%%% Strings for the preprint titlepage footer:

\newif\if@preprint\@preprintfalse
\def\ds@preprint{\@preprinttrue}
\def\ps@preprint{\let\@mkboth\@gobbletwo\def\@oddhead{}
  \def\@oddfoot{\rlap{\@toappear}\hfil\thepage\hfil
    \llap{\@copyrightnotice}\gdef\@toappear{}\gdef\@copyrightnotice{}}}

\if@preprint\ps@preprint
\else\ps@empty\flushbottom\fi

\def\thebibliography#1{\section{References}\eightpt\list
 {[\arabic{enumi}]}{\settowidth\labelwidth{[#1]}\leftmargin\labelwidth
 \advance\leftmargin\labelsep
 \usecounter{enumi}}
 \def\newblock{\hskip .11em plus .33em minus .07em}
 \sloppy\clubpenalty4000\widowpenalty4000
 \sfcode`\.=1000\relax}
\let\endthebibliography=\endlist

\flushbottom
%%%%% fancyheading included
\def\lhead{\@ifnextchar[{\@xlhead}{\@ylhead}}
\def\@xlhead[#1]#2{\gdef\@elhead{#1}\gdef\@olhead{#2}}
\def\@ylhead#1{\gdef\@elhead{#1}\gdef\@olhead{#1}}

\def\chead{\@ifnextchar[{\@xchead}{\@ychead}}
\def\@xchead[#1]#2{\gdef\@echead{#1}\gdef\@ochead{#2}}
\def\@ychead#1{\gdef\@echead{#1}\gdef\@ochead{#1}}

\def\rhead{\@ifnextchar[{\@xrhead}{\@yrhead}}
\def\@xrhead[#1]#2{\gdef\@erhead{#1}\gdef\@orhead{#2}}
\def\@yrhead#1{\gdef\@erhead{#1}\gdef\@orhead{#1}}

\def\lfoot{\@ifnextchar[{\@xlfoot}{\@ylfoot}}
\def\@xlfoot[#1]#2{\gdef\@elfoot{#1}\gdef\@olfoot{#2}}
\def\@ylfoot#1{\gdef\@elfoot{#1}\gdef\@olfoot{#1}}

\def\cfoot{\@ifnextchar[{\@xcfoot}{\@ycfoot}}
\def\@xcfoot[#1]#2{\gdef\@ecfoot{#1}\gdef\@ocfoot{#2}}
\def\@ycfoot#1{\gdef\@ecfoot{#1}\gdef\@ocfoot{#1}}

\def\rfoot{\@ifnextchar[{\@xrfoot}{\@yrfoot}}
\def\@xrfoot[#1]#2{\gdef\@erfoot{#1}\gdef\@orfoot{#2}}
\def\@yrfoot#1{\gdef\@erfoot{#1}\gdef\@orfoot{#1}}

\newdimen\headrulewidth
\newdimen\footrulewidth
\newdimen\plainheadrulewidth
\newdimen\plainfootrulewidth
\newdimen\headwidth
\newif\if@fancyplain
\def\fancyplain#1#2{\if@fancyplain#1\else#2\fi}

% Command to reset various things in the headers:
% a.o.  single spacing (taken from setspace.sty)
% and the catcode of ^^M (so that epsf files in the header work if a
% verbatim crosses a page boundary)
\def\fancy@reset{\restorecr
 \def\baselinestretch{1}%
 \ifx\undefined\@newbaseline% NFSS not present; 2.09 or 2e
  \ifx\@currsize\normalsize\@normalsize\else\@currsize\fi%
 \else% NFSS (2.09) present
  \@newbaseline%
 \fi}

% Initialization of the head and foot text.

\headrulewidth 0.4pt
\footrulewidth\z@
\plainheadrulewidth\z@
\plainfootrulewidth\z@

\lhead[\fancyplain{}{\sl\rightmark}]{\fancyplain{}{\sl\leftmark}}
%  i.e. empty on ``plain'' pages, \rightmark on even, \leftmark on odd pages
\chead{}
%\rhead[\fancyplain{}{\sl\leftmark}]{\fancyplain{}{\sl\rightmark}}
%  i.e. empty on ``plain'' pages, \leftmark on even, \rightmark on odd pages
\lfoot{}
\cfoot{}
\rfoot{}

% Put together a header or footer given the left, center and
% right text, fillers at left and right and a rule.
% The \lap commands put the text into an hbox of zero size,
% so overlapping text does not generate an errormessage.

\def\@fancyhead#1#2#3#4#5{#1\hbox to\headwidth{\fancy@reset\vbox{\hbox
{\rlap{\parbox[b]{\headwidth}{\raggedright#2\strut}}\hfill
\parbox[b]{\headwidth}{\centering#3\strut}\hfill
\llap{\parbox[b]{\headwidth}{\raggedleft#4\strut}}}\headrule}}#5}


\def\@fancyfoot#1#2#3#4#5{#1\hbox to\headwidth{\fancy@reset\vbox{\footrule
\hbox{\rlap{\parbox[t]{\headwidth}{\raggedright#2\strut}}\hfill
\parbox[t]{\headwidth}{\centering#3\strut}\hfill
\llap{\parbox[t]{\headwidth}{\raggedleft#4\strut}}}}}#5}

\def\headrule{{\if@fancyplain\let\headrulewidth\plainheadrulewidth\fi
\hrule\@height\headrulewidth\@width\headwidth \vskip-\headrulewidth}}

\def\footrule{{\if@fancyplain\let\footrulewidth\plainfootrulewidth\fi
\vskip-0.3\normalbaselineskip\vskip-\footrulewidth
\hrule\@width\headwidth\@height\footrulewidth\vskip0.3\normalbaselineskip}}

\def\ps@fancy{%
\@ifundefined{@chapapp}{\let\@chapapp\chaptername}{}%for amsbook
\@ifundefined{chapter}{\def\sectionmark##1{\markboth
{\uppercase{\ifnum \c@secnumdepth>\z@
 \thesection\hskip 1em\relax \fi ##1}}{}}%
\def\subsectionmark##1{\markright {\ifnum \c@secnumdepth >\@ne
 \thesubsection\hskip 1em\relax \fi ##1}}}%
{\def\chaptermark##1{\markboth {\uppercase{\ifnum \c@secnumdepth>\m@ne
 \@chapapp\ \thechapter. \ \fi ##1}}{}}
\def\sectionmark##1{\markright{\uppercase{\ifnum \c@secnumdepth >\z@
 \thesection. \ \fi ##1}}}}%
\csname ps@headings\endcsname % use \ps@headings defaults if they exist
\ps@@fancy
\gdef\ps@fancy{\@fancyplainfalse\ps@@fancy}%
\headwidth\textwidth}
\def\ps@fancyplain{\ps@fancy \let\ps@plain\ps@plain@fancy}
\def\ps@plain@fancy{\@fancyplaintrue\ps@@fancy}
\def\ps@@fancy{%
\def\@mkboth{\protect\markboth}%
\def\@oddhead{\@fancyhead\@lodd\@olhead\@ochead\@orhead\@rodd}%
\def\@oddfoot{\@fancyfoot\@lodd\@olfoot\@ocfoot\@orfoot\@rodd}%
\def\@evenhead{\@fancyhead\@rodd\@elhead\@echead\@erhead\@lodd}%
\def\@evenfoot{\@fancyfoot\@rodd\@elfoot\@ecfoot\@erfoot\@lodd}%
}
\def\@lodd{\if@reversemargin\hss\else\relax\fi}
\def\@rodd{\if@reversemargin\relax\else\hss\fi}

\let\latex@makecol\@makecol
\def\@makecol{\let\topfloat\@toplist\let\botfloat\@botlist\latex@makecol}
\def\iftopfloat#1#2{\ifx\topfloat\empty #2\else #1\fi}
\def\ifbotfloat#1#2{\ifx\botfloat\empty #2\else #1\fi}
\def\iffloatpage#1#2{\if@fcolmade #1\else #2\fi}

\sisetup{detect-all}
